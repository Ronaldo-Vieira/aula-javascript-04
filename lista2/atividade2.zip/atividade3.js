var atividades = [
    "Acorda",
    "Comer",
    "Escovar os dentes",
    "Estudar",
    "Arruma cama",
    "Por come do cachorro",
    "Passear com o cachorro"
]
var favoritas = [
    " Comer ",
    " Codar ",
]
var juncao = (atividades.join() +  favoritas.join())

console.log(atividades[3])
console.log(atividades[6])
console.log(atividades.join(" - "))
console.log(juncao)
