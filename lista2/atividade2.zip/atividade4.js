var cidades = [
    "São Paulo",
    "Rio de Janeiro",
    "Curitiba",
    "Salvador",
    "Recife"
]

console.log(cidades.sort())
cidades.shift()
cidades.pop()
console.log(cidades)