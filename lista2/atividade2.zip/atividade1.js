var listaNum = [25, 23, 11, 55, 30,  6, 4, 21, 34, 89, 56]
console.log(listaNum.sort())